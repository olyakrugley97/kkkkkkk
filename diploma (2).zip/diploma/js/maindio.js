
$('[data-modal]').click(function() {

	var target = $(this).attr('data-modal');

	if (target == 'close') {
		$('.modal-container').removeClass('active');
		$('.modal-container .modal').removeClass('active');
	} else {
		$('.modal-container').addClass('active');
		$('.modal-container .modal' + target).addClass('active');
	}


});